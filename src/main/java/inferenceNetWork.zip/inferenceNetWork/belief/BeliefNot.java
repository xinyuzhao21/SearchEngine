package inferenceNetWork.belief;

import inferenceNetWork.QueryNode;

public class BeliefNot extends BeliefNode {
    @Override
    public double score(int docID) {
        double s = this.children.get(0).score(docID);
        double p = Math.exp(s);
        return Math.log(1-p);
    }
}
