package inferenceNetWork.filter;

public class FilterReject {
}
