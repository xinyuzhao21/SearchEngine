package inferenceNetWork.filter;

import inferenceNetWork.QueryNode;

public abstract class FilterNode extends QueryNode {
    @Override
    public double score(int docID) {
        return 0;
    }

    @Override
    public int nextCandidate() {
        return 0;
    }

    @Override
    public void skipTo(int docID) {

    }
}
